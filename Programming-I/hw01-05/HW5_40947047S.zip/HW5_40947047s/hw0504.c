#include <stdio.h>
#include "hw05.h"
int main(){
    regression();
}
