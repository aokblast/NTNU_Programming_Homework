#include <stdint.h>
#define i32 int32_t
void DecToRoman(i32);
double natural_log(i32);
void hanoi_recursive(i32,i32,i32,i32);
void hanoi_loop(i32,i32,i32,i32);
double eqresis(i32,i32);
void bac_init();
