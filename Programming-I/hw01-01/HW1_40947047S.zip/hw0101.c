#include <stdio.h>

int main(){
	printf("My student ID is 40947047s\nMy name is 洪盛益.\n");
}
