#include <stdint.h>
#define i32 int32_t
#define u8 uint8_t

void project(double *,double *,double *,i32,i32,i32,i32);
void showplane(i32,i32,i32,i32);
void texteditor();
void rotate(double *,double *,double);
void print_card(const u8 player[13]);
i32 sort_card(u8 player[13],i32 (*compare)(i32,i32));
void print_card(const u8 player[13]);
i32 func01(i32,i32),func02(i32,i32),func03(i32,i32);
void value_check(const u8 player1[13],const u8 player2[13],const u8 player3[13],const u8 player4[13]);
