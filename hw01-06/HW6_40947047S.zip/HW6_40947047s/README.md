Student ID:40947047s
Student Name:洪盛益

Build:
just run make to build all source code.

Run:
use ./hw0601,./hw0602....etc to run your code.

Clear:
use make clear to clear all compiled code.

hw0601-hw0605:
Just execute the executable file.

hw00606:
read the pdf(hw0606.pdf).
