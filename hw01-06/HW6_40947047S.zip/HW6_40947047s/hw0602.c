#include "hw06.h"

int main(){
    texteditor();

}
