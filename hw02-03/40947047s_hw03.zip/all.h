#ifndef ALL
#define ALL

//header

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <iso646.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <signal.h>
#include <setjmp.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <uchar.h>
#include <wchar.h>
#include <wctype.h>

//type-alias

typedef char string[10005]; 
typedef FILE *fstream;
typedef int64_t array[10005];

// Useful macro
#define auto(a, b) typeof(a) a = b


#endif
