#ifndef GTKGUI
#define GTKGUI

#include "all.h"
#include <gtk/gtk.h>



typedef GtkWidget *gtkobj;
typedef GtkFileFilter *gtkfobj;

void init_Window();

#endif