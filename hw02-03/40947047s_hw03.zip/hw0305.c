#include "all.h"
#include "gui.h"
#include "terminal.h"

int main(){
    
    init_term();

}