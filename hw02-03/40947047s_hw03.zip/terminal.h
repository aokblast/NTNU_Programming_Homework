#ifndef TERMINAL
#define TERMINAL


void init_term();

#endif