name:洪盛益  
student ID:40947047s

build:

use make to build source code

clear: 

use make clear to clean all executable file

./hw0301, ./hw0302:
Just Execute the file.

./hw0303:
Execute the file.
0 and 90 degree will result in error and terminate the program.

./hw0304:
Just Execute the file.

./hw0305:
1. You can only type integer
2. Can't have totally same data on city, commander, monarch

Can't change phy and active and age