#ifndef MYPRINTF
#define MYPRINTF

#include "all.h"

int myprintf(char *, ... );

#endif