#include "all.h"
#include "myprintf.h"

int main(){
    printf("Test: %d\n", printf("%d123123 %s\n", 123, "abcde\n"));
    printf("Test: %d\n", printf("%d123123 %s\n", 123, "abcde\n"));
}