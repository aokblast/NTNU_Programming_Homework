#include <stdio.h>
#include <math.h>

int main() {

    sqrt(-1);
    perror("Wrong sqrt number");
}