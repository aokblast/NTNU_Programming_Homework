char *pStr01 = "Hello";
char *pStr02 = "World";

void print_answers() {
    printf("String 01:\n");
    printf("%s\n", pStr01);
    printf("String 02:\n");
    printf("%s\n", pStr02);

}