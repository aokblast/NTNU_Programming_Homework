char *mystrchr(const char *str, int c);
char *mystrrchr(const char *str, int c);
size_t mystrspn(const char *str, const char *accept);
size_t mystrcspn(const char *str, const char *reject);
char *mystrpbrk(const char *str, const char *accept);
char *mystrstr(const char *haystack, const char *needle);
char *mystrtok(char *str,const char *delim);