void getaline(char target[], int buffer);
int gotaline(char target[], int buffer);