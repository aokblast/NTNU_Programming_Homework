import sqlite3 as sq

def dbconnect(dbname):
    resultDB=sq.connect(dbname)
    resultC=resultDB.cursor()
    return resultDB,resultC

def dbclose(cursor,db):
    cursor.close()
    db.commit()
    db.close()

def tbcreate():
    db,cursor=dbconnect('ChatComment.db')
    cursor.execute('create table user (time text, comment text)')
    dbclose(cursor,db)

def dbwrite(time,msg):
    db,cursor=dbconnect('ChatComment.db')
    insertvalue=[time,msg]
    cursor.execute("""insert into user (time, comment) values (?, ?)""",insertvalue)
    dbclose(cursor,db)

def getData(db):
    resultLIST=[]
    db,cursor=dbconnect(db)
    data=cursor.execute('SELECT comment FROM user')
    datas=list(data)
    for i in datas:
        resultLIST.append(i[0])
    dbclose(cursor,db)
    return resultLIST
