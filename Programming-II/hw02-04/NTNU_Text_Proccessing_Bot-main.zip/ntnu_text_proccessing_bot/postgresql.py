import psycopg2


class Db:
    def __init__(self, user, db):
        conn = None
        try:
            # in auto commit mode and no commit is required
            self.conn = psycopg2.connect(
                database=db, user=user, host="/var/run/postgresql")
            self.conn.set_session(autocommit=True)
            # create cursor
            self.cur = self.conn.cursor()
        finally:
            if conn is not None:
                conn.close()
                print("DB connection closed in an error")

    def write(self, time, uid, message):
        self.cur.execute(
            'insert into sedneocat (pubtime, authorid, comment) values (%s, %s, %s) on conflict do nothing;', (time, uid, message))

    def getAll(self):
        ret = []
        self.cur.execute("SELECT comment FROM sedneocat;")
        fetch = self.cur.fetchall()
        for v in fetch:
            ret.append(v[0])
        return ret

    def cleanup(self):
        self.cur.close()
        self.conn.close()
