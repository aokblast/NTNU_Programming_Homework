CREATE TABLE sedneocat(
    pubtime timestamptz,
    authorid VARCHAR(50),
    comment TEXT,
    PRIMARY KEY(pubtime, authorid)
);