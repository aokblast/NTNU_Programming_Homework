import requests
import json
import time
import os
import sys

import googleapiclient.discovery
import googleapiclient.errors
from googleapiclient.errors import HttpError


class LiveChat:
    def __init__(self, key, channelID):
        self.channelID = channelID
        self.vID = ""
        self.chatID = ""
        self.key = key

    # Quota impact !! Deprecated
    def fetch_vID(self):
        params = {
            'part': 'id',
            'key': self.key,
            'channelId': self.channelID,
            'eventType': 'live',
            'type': 'video',
            'order': 'viewCount',
            'fields': 'items(id(videoId))'
        }

        url = 'https://www.googleapis.com/youtube/v3/search'
        r = requests.get(url, headers=None, params=params).json()
        self.vID = r.get('items')[0].get('id').get('videoId')
        return self.vID

    def fetch_chatID(self):
        params = {
            'part': 'liveStreamingDetails,statistics,snippet',
            'key': self.key,
            'id': self.vID,
            'fields': 'items(id,liveStreamingDetails(activeLiveChatId,concurrentViewers,actualStartTime),' +
            'snippet(channelId,channelTitle,description,liveBroadcastContent,publishedAt,thumbnails,title),statistics)'
        }

        url = 'https://www.googleapis.com/youtube/v3/videos'
        r = requests.get(url, headers=None, params=params).json()

        streamData = dict(r.get('items')[0])

        self.chatID = streamData['liveStreamingDetails']['activeLiveChatId']
        return self.chatID

    def fetch(self):
        self.fetch_vID()
        self.fetch_chatID()

    def get_message(self):
        params = {
            'part': 'snippet',
            'key': self.key,
            'liveChatId': self.chatID,
            # 'profileImageSize': 720,
            'maxResults': 200
        }

        url = 'https://www.googleapis.com/youtube/v3/liveChat/messages'
        pageToken = ""
        response = None
        while True:
            params['pageToken'] = pageToken
            response = requests.get(url, headers=None, params=params).json()
            items = response['items']
            for item in items:
                if "liveChatId" in item['snippet']:
                    yield item['snippet']
                else:
                    pass
            pageToken = response['nextPageToken']
            if pageToken is None or len(pageToken) <= 0:
                break
            time.sleep(response['pollingIntervalMillis']/1000)


class DataCache:
    def __init__(self, cachePath):
        self.map = {}
        self.path = cachePath
        if os.path.isfile(cachePath):
            with open(self.path, "r") as f:
                data = json.load(f)
                for k, v in data.items():
                    self.map[k] = (v, None, None)

    def flush(self):
        mp = {}
        for k, v in self.map.items():
            mp[k] = v[0]
        with open(self.path, "w+") as f:
            json.dump(mp, f)

    def setCallback(self, key, callback, **kwargs):
        if key in self.map:
            # key exist in file cache
            self.map[key] = (self.map[key][0], callback, kwargs)
        else:
            # if key not exist => create
            self.map[key] = (None, callback, kwargs)
            self.failed(key)

    def getKeys(self):
        ret = []
        for k, _ in self.map:
            ret.append(k)
        return ret

    def getData(self, key):
        return self.map[key][0]

    # When getData returned deprecated data, use callback to update it
    def failed(self, key):
        if self.map[key][1] is not None:
            self.map[key] = (self.map[key][1](**self.map[key][2]),
                             self.map[key][1], self.map[key][2])
        return self.map[key][0]


class LiveChatGapi:
    def __init__(self, key, channelID, cachePath):
        self.channelID = channelID
        self.key = key
        # Setup APIs
        self.api = googleapiclient.discovery.build(
            "youtube", "v3", developerKey=key)
        self.cache = DataCache(cachePath)
        self.cache.setCallback("vid", self.fetch_vID)
        self.cache.setCallback("chatid", self.fetch_chatID)
        self.cache.flush()

    def fetch_vID(self):
        params = {
            'part': 'id',
            'key': self.key,
            'channelId': self.channelID,
            'eventType': 'live',
            'type': 'video',
            'order': 'viewCount',
            'fields': 'items(id(videoId))'
        }
        req = self.api.search().list(**params)
        resp = req.execute()

        self.vID = resp['items'][0]['id']['videoId']
        return self.vID

    def fetch_chatID(self):
        params = {
            'part': 'liveStreamingDetails',
            'key': self.key,
            'id': self.cache.getData('vid'),
            'fields': 'items(id,liveStreamingDetails(activeLiveChatId))',
        }
        req = self.api.videos().list(**params)
        resp = None
        try:
            resp = req.execute()
            # parse data
            streamData = dict(resp['items'][0])
            self.chatID = streamData['liveStreamingDetails']['activeLiveChatId']
        except Exception:
            # error handling
            params['id'] = self.cache.failed('vid')
            req = self.api.videos().list(**params)
            resp = req.execute()

            streamData = dict(resp['items'][0])
            self.chatID = streamData['liveStreamingDetails']['activeLiveChatId']
        return self.chatID

    def fetch(self):
        print("\"fetch\" method is now a dummy method.", file=sys.stderr)

    def get_message(self):
        params = {
            'part': 'snippet',
            'key': self.key,
            'liveChatId': self.cache.getData('chatid'),
            # 'profileImageSize': 720,
            'maxResults': 200,
            'fields': 'nextPageToken, pollingIntervalMillis,items(snippet(authorChannelId, publishedAt, hasDisplayContent, displayMessage))'
        }
        req = self.api.liveChatMessages().list(**params)
        pageToken = ""
        response = None
        while True:
            params['pageToken'] = pageToken
            response = None
            try:
                response = req.execute()
            except HttpError:
                params['liveChatId'] = self.cache.failed('chatid')
                req = self.api.liveChatMessages().list(**params)
                response = req.execute()
            # parse
            items = response['items']
            for item in items:
                if "hasDisplayContent" in item['snippet'] and item['snippet']['hasDisplayContent']:
                    yield item['snippet']
                else:
                    pass
            if 'nextPageToken' not in response:
                break
            pageToken = response['nextPageToken']
            time.sleep(response['pollingIntervalMillis']/1000)
