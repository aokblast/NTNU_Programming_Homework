#!/usr/local/env python
import bot
import settings
#import database as db
from postgresql import Db

# 中天新聞
channelID = 'UC5l1Yto5oOIgRXlI4p4VKbw'


def main():
    live = bot.LiveChatGapi(settings.API_KEY, channelID, './cache.json')
    db = Db("nlp2020", "nlp2020")
    try:
        for message in live.get_message():
            #db.dbwrite(message['publishedAt'], message['displayMessage'])
            db.write(message['publishedAt'],
                     message['authorChannelId'], message['displayMessage'])
            print(message['publishedAt'], message['displayMessage'], sep=' ')
    finally:
        # clean up stage
        live.cache.flush()
        db.cleanup()


if __name__ == "__main__":
    # db.tbcreate()
    main()
