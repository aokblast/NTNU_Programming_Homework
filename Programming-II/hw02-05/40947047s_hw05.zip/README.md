name:洪盛益  
student ID:40947047s

build:

use make to build source code

clear: 

use make clear to clean all executable file

hw0501 hw0502 hw0503:
just execute the file

hw0504:
just read the pdf


