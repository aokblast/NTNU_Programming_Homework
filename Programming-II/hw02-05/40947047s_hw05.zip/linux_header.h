#ifndef LINUXHEADER
#define LINUXHEADER

#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <getopt.h>
#endif
