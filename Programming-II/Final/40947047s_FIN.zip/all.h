#ifndef ALL
#define ALL

//header

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <iso646.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <signal.h>
#include <setjmp.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <uchar.h>
#include <wchar.h>
#include <wctype.h>

//type-alias

typedef char string[10005]; 
typedef FILE *fstream;
typedef int64_t array[10005];
typedef int64_t i64;
typedef uint64_t u64;
typedef int32_t i32;
typedef uint32_t u32;
typedef int16_t i16;
typedef uint16_t u16;
typedef int8_t i8;
typedef uint8_t u8;
typedef unsigned char uchar_t;

// Useful macro
#define auto(a, b) typeof(a) a = b
#define STREQ(a, b) (strcmp(a, b) == 0)


#endif
