#include <stdio.h>
#include "hw05.h"

int main(){
    game_init();

}
