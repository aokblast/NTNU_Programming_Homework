#include "hw05.h"

int main(){
    poly();
}
