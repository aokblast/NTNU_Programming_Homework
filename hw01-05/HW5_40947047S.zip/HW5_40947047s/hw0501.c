#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "hw05.h"
#include "test.h"

#define int32_t i32

int main(){
    sorting(array,array_size);    
}
