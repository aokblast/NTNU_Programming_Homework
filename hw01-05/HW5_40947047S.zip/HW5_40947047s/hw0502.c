#include <stdio.h>
#include <stdint.h>
#include "test2.h"
#include "hw05.h"
#define i32 int32_t

int main(){
    printf("%d\n",deter((i32 *)matrix,4));

}
