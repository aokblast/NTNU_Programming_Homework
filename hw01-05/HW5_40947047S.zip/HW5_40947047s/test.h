#include <stdint.h>
int32_t array[10]={75,23,-53,105,123,72,-24,52,1024,1537};
int32_t array_size=10;
