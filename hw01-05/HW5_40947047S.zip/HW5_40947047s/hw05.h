#include <stdint.h>
#define i32 int32_t

void sorting(i32 *,i32);
i32 deter(i32 *,i32);
void poly();
void regression();
void game_init();
