#include <stdio.h>

int main(){
	printf("\033[1;31mHello World!\n");
}
