#ifndef UTLI
#define UTLI
#include <stdint.h>
int64_t gcd(int64_t, int64_t);
void swapi64(int64_t *, int64_t *);
#endif