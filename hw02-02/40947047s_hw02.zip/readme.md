name:洪盛益  
student ID:40947047s

build:

use make to build source code

clear: 

use make clear to clean all executable file

./hw0201:

If the divisor is zero, the function will set pNumber to zero and print error message.

./hw0202:

./hw0203:

./hw0204:

The divide is c type;

If the divisor is 0, pQuotient = 0 and pRemainder = num01 and print error msg

hw0205.pdf:

